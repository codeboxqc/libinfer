cmake_minimum_required(VERSION 3.22)
project(orange10g VERSION 2.0.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# RK3588 / Orange Pi 5 Max optimized libinfer + llama.cpp flags
set(INFER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE ON CACHE BOOL "" FORCE)
set(GGML_CPU_REPACK ON CACHE BOOL "" FORCE)
add_subdirectory(third_party/libinfer)

find_package(OpenSSL REQUIRED)
find_package(Threads REQUIRED)

# SQLite3 amalgamation with FTS5 enabled
add_library(sqlite3_static STATIC
    third_party/deps/sqlite3.c
)
target_include_directories(sqlite3_static PUBLIC third_party/deps)
target_compile_definitions(sqlite3_static PUBLIC
    SQLITE_ENABLE_FTS5
    SQLITE_THREADSAFE=1
)
if(UNIX)
    target_link_libraries(sqlite3_static PUBLIC dl Threads::Threads)
endif()

# Embed web UI assets into generated header
set(EMBEDDED_UI_HEADER "${CMAKE_CURRENT_BINARY_DIR}/generated/embedded_ui.hpp")
add_custom_command(
    OUTPUT "${EMBEDDED_UI_HEADER}"
    COMMAND ${CMAKE_COMMAND}
        -DSRC_DIR=${CMAKE_CURRENT_SOURCE_DIR}/web
        -DOUT_FILE=${EMBEDDED_UI_HEADER}
        -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_ui.cmake
    DEPENDS
        ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_ui.cmake
        ${CMAKE_CURRENT_SOURCE_DIR}/web/index.html
        ${CMAKE_CURRENT_SOURCE_DIR}/web/manifest.json
        ${CMAKE_CURRENT_SOURCE_DIR}/web/sw.js
    COMMENT "Embedding orange10g web UI assets into embedded_ui.hpp"
)

add_executable(opi_ai_10g
    src/main.cpp
    src/engine.cpp
    src/hw_monitor.cpp
    src/downloader.cpp
    src/workspace.cpp
    src/database.cpp
    src/network.cpp
    src/tts.cpp
    third_party/deps/qrcodegen.cpp
    "${EMBEDDED_UI_HEADER}"
)

target_include_directories(opi_ai_10g PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/deps
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/libinfer/include
    ${CMAKE_CURRENT_BINARY_DIR}/generated
)

target_compile_definitions(opi_ai_10g PRIVATE
    CPPHTTPLIB_OPENSSL_SUPPORT
)

target_link_libraries(opi_ai_10g PRIVATE
    infer_core
    sqlite3_static
    OpenSSL::SSL
    OpenSSL::Crypto
    Threads::Threads
    dl
)

if(UNIX AND NOT APPLE)
    set_target_properties(opi_ai_10g PROPERTIES
        BUILD_RPATH "$ORIGIN:$ORIGIN/bin:$ORIGIN/../lib:$ORIGIN/third_party/libinfer:$ORIGIN/third_party/libinfer/third_party/llama.cpp/bin"
        INSTALL_RPATH "$ORIGIN:$ORIGIN/../lib"
    )
    if(TARGET ggml-cpu)
        add_custom_command(TARGET opi_ai_10g POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_FILE:ggml-cpu>
                $<TARGET_FILE_DIR:opi_ai_10g>/
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_FILE:ggml-cpu>
                $<TARGET_FILE_DIR:infer_core>/
            COMMENT "Copying ggml-cpu backend next to opi_ai_10g and libinfer"
        )
    endif()
endif()

# Optional: build native RKLLM NPU bridge plugin automatically if official rkllm.h & librkllmrt.so are installed
set(RKLLM_INCLUDE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/rkllm/include" CACHE PATH "Path to official rkllm.h")
set(RKLLM_LIB_DIR "${CMAKE_CURRENT_SOURCE_DIR}/lib" CACHE PATH "Path to librkllmrt.so")

if(EXISTS "${RKLLM_INCLUDE_DIR}/rkllm.h" AND EXISTS "${RKLLM_LIB_DIR}/librkllmrt.so")
    message(STATUS "[orange10g] Building native RKLLM NPU bridge plugin (libopi_rkllm_bridge.so)")
    add_library(opi_rkllm_bridge SHARED src/rkllm_bridge.cpp)
    target_include_directories(opi_rkllm_bridge PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/src
        ${RKLLM_INCLUDE_DIR}
    )
    target_link_libraries(opi_rkllm_bridge PRIVATE "${RKLLM_LIB_DIR}/librkllmrt.so" Threads::Threads dl)
    set_target_properties(opi_rkllm_bridge PROPERTIES
        BUILD_RPATH "$ORIGIN:${RKLLM_LIB_DIR}:/usr/local/lib:/usr/lib"
        INSTALL_RPATH "$ORIGIN"
    )
    add_custom_command(TARGET opi_rkllm_bridge POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            $<TARGET_FILE:opi_rkllm_bridge>
            ${CMAKE_CURRENT_SOURCE_DIR}/lib/
        COMMENT "Copying libopi_rkllm_bridge.so into lib/"
    )
else()
    message(STATUS "[orange10g] RKLLM SDK not yet installed (run ./scripts/install_rkllm_runtime.sh to enable 6-TOPS NPU plugin)")
endif()
