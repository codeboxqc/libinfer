#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VOICES_DIR="$SCRIPT_DIR/voices"
MODELS_DIR="$SCRIPT_DIR/models"
LIB_DIR="$SCRIPT_DIR/lib"
BUILD_DIR="$SCRIPT_DIR/build"

# Raise file descriptor limit (recommended by Rockchip RKLLM runtime)
ulimit -n 65536 2>/dev/null || true

# Avoid OpenMP busy-spin livelocks when background HTTP/TTS threads wake up
export OMP_WAIT_POLICY=PASSIVE

# Ensure librkllmrt.so, libopi_rkllm_bridge.so, libinfer.so, and libggml-cpu.so resolve cleanly
export LD_LIBRARY_PATH="${LIB_DIR}:${BUILD_DIR}:${BUILD_DIR}/bin:${BUILD_DIR}/third_party/libinfer:${LD_LIBRARY_PATH:-}"

# Parse launcher hints first
EXTRA_ARGS=()
HAS_MODELS_DIR=0
NO_PIN=0
NO_DOWNLOAD=0
for arg in "$@"; do
    [ "$arg" = "--models-dir" ] && HAS_MODELS_DIR=1
    [ "$arg" = "--no-pin" ] && NO_PIN=1
    [ "$arg" = "--no-download" ] && NO_DOWNLOAD=1
done

# 1. Check Piper TTS binary (skip auto-install when --no-download is set, use short timeout)
if [ "$NO_DOWNLOAD" -eq 0 ] && ! command -v piper >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/piper" ] && [ ! -x "/usr/local/bin/piper" ]; then
    if command -v pip3 >/dev/null 2>&1; then
        echo "[setup] Installing piper-tts for neural voice..."
        pip3 install --user -q --retries 1 --timeout 5 piper-tts || echo "[setup] Note: pip3 install piper-tts failed; using Phone Web Speech."
    fi
fi

# 2. Ensure Piper neural voices exist (copied or downloaded into ./voices/)
download_voice() {
    local name="$1"
    local url_base="$2"
    if [ "$NO_DOWNLOAD" -eq 0 ] && { [ ! -f "$VOICES_DIR/${name}.onnx" ] || [ ! -f "$VOICES_DIR/${name}.onnx.json" ]; }; then
        mkdir -p "$VOICES_DIR"
        echo "[setup] Downloading voice: ${name}..."
        curl -fL --connect-timeout 8 --max-time 60 -o "$VOICES_DIR/${name}.onnx" "${url_base}/${name}.onnx" || true
        curl -fL --connect-timeout 8 --max-time 60 -o "$VOICES_DIR/${name}.onnx.json" "${url_base}/${name}.onnx.json" || true
    fi
}
download_voice "en_US-amy-medium" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium"
download_voice "en_GB-jenny_dioco-medium" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/jenny_dioco/medium"

# 3. Default to NVMe ./models directory unless user passed --models-dir
if [ "$HAS_MODELS_DIR" -eq 0 ]; then
    EXTRA_ARGS+=(--models-dir "$MODELS_DIR")
fi

# 4. Helpful hardware status hints
if [ ! -f "$LIB_DIR/libopi_rkllm_bridge.so" ]; then
    echo "[tip] 6-TOPS NPU plugin not installed yet. To enable .rkllm NPU models, run:"
    echo "      ./scripts/install_rkllm_runtime.sh"
fi
if [ -f /sys/class/devfreq/dmc/governor ]; then
    DMC_GOV="$(cat /sys/class/devfreq/dmc/governor 2>/dev/null || true)"
    NPU_GOV="$(cat /sys/class/devfreq/fdab0000.npu/governor 2>/dev/null || true)"
    if [ "$DMC_GOV" != "performance" ] || [ "$NPU_GOV" != "performance" ]; then
        echo "[tip] For maximum LLM speed on Orange Pi 5 Max (2.4 GHz DDR + 1.0 GHz NPU), run:"
        echo "      sudo ./scripts/tune_opi5max.sh"
    fi
fi

# 5. Auto-build from source on first run (e.g. fresh GitHub clone with no prebuilt binary)
if [ ! -x "$BUILD_DIR/opi_ai_10g" ]; then
    echo "[build] Compiling opi_ai_10g from source (Release)..."
    cmake -S "$SCRIPT_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release
    cmake --build "$BUILD_DIR" -j4
fi

# 6. Launch server across all cores so Linux EAS puts the 4 inference threads on Cortex-A76 (4-7)
#    while HTTP/HTTPS, SQLite, and Piper TTS run on Cortex-A55 (0-3) without starving OpenMP!
exec "$BUILD_DIR/opi_ai_10g" "${EXTRA_ARGS[@]}" "$@"
