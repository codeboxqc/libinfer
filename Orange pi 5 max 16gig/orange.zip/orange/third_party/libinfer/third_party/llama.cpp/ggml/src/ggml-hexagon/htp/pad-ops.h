#ifndef HTP_PAD_OPS_H
#define HTP_PAD_OPS_H

#include "hex-common.h"
#include "hex-fastdiv.h"
#include "htp-vtcm.h"
#include <stdint.h>

enum htp_pad_kernel_type {
    HTP_PAD_KERNEL_HVX          = 0,
    HTP_PAD_KERNEL_HVX_CIRCULAR = 1,
};

struct htp_pad_vtcm_layout {
    size_t total_bytes;
    size_t off_src0;
    size_t off_dst;
    size_t chunk_bytes_aligned;
    size_t src0_bytes_per_hvx;
    size_t dst_bytes_per_hvx;
};

static inline void htp_pad_vtcm_layout_build(
    struct htp_pad_vtcm_layout * L,
    size_t                       chunk_bytes,
    uint32_t                     n_hvx
) {
    L->chunk_bytes_aligned = hex_round_up(chunk_bytes, 128);
    L->src0_bytes_per_hvx  = 2 * L->chunk_bytes_aligned;
    L->dst_bytes_per_hvx   = 2 * L->chunk_bytes_aligned;

    size_t off = 0;
    VTCM_LAYOUT_ALLOC(off, off_src0, L->src0_bytes_per_hvx * n_hvx);
    VTCM_LAYOUT_ALLOC(off, off_dst,  L->dst_bytes_per_hvx * n_hvx);

    L->total_bytes = off;
}

struct htp_pad_kernel_params {
    uint8_t  kernel_type;
    uint32_t n_hvx;
    uint32_t total_rows;
    uint32_t chunk_elems;
    uint32_t elem_size;
    uint32_t vtcm_size;

    struct fastdiv_values div_ne1;
    struct fastdiv_values div_ne1_ne2;
    struct fastdiv_values div_ne01;
    struct fastdiv_values div_ne02;
    struct fastdiv_values div_ne03;
};

#if defined(__cplusplus)
static_assert(sizeof(struct htp_pad_kernel_params) <= 128, "htp_pad_kernel_params is too large for kernel_params blob");
#else
_Static_assert(sizeof(struct htp_pad_kernel_params) <= 128, "htp_pad_kernel_params is too large for kernel_params blob");
#endif

#endif // HTP_PAD_OPS_H
