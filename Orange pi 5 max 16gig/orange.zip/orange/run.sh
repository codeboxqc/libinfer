#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VOICES_DIR="$SCRIPT_DIR/voices"
MODELS_DIR="$SCRIPT_DIR/models"

# 1. First-run Piper TTS binary auto-install
if ! command -v piper >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/piper" ] && [ ! -x "/usr/local/bin/piper" ]; then
    if command -v pip3 >/dev/null 2>&1; then
        echo "[setup] Installing piper-tts for neural voice..."
        pip3 install --user -q piper-tts || echo "[setup] Note: pip3 install piper-tts failed; using Phone Web Speech."
    elif command -v pip >/dev/null 2>&1; then
        echo "[setup] Installing piper-tts for neural voice..."
        pip install --user -q piper-tts || echo "[setup] Note: pip install piper-tts failed; using Phone Web Speech."
    else
        echo "[setup] pip not found. To enable Piper neural voice later: pip install piper-tts"
    fi
fi

# 2. First-run Piper voice models auto-download
download_voice() {
    local name="$1"
    local url_base="$2"
    if [ ! -f "$VOICES_DIR/${name}.onnx" ] || [ ! -f "$VOICES_DIR/${name}.onnx.json" ]; then
        mkdir -p "$VOICES_DIR"
        echo "[setup] Downloading voice: ${name}..."
        curl -fL --connect-timeout 15 -o "$VOICES_DIR/${name}.onnx" "${url_base}/${name}.onnx" || true
        curl -fL --connect-timeout 15 -o "$VOICES_DIR/${name}.onnx.json" "${url_base}/${name}.onnx.json" || true
    fi
}

download_voice "en_US-amy-medium" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium"
download_voice "en_GB-jenny_dioco-medium" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/jenny_dioco/medium"

# 3. Default to NVMe models directory unless user passed --models-dir
EXTRA_ARGS=()
HAS_MODELS_DIR=0
for arg in "$@"; do
    if [ "$arg" = "--models-dir" ]; then
        HAS_MODELS_DIR=1
        break
    fi
done
if [ "$HAS_MODELS_DIR" -eq 0 ]; then
    EXTRA_ARGS+=(--models-dir "$MODELS_DIR")
fi

# 4. Network / firewall hint
if command -v ufw >/dev/null 2>&1; then
    if ufw status 2>/dev/null | grep -qi "Status: active"; then
        echo "[setup] UFW firewall is active. If phone cannot connect, run: sudo ufw allow 8080/tcp"
    fi
fi

# Auto-build from source on first run (e.g. fresh GitHub clone with no prebuilt binary)
if [ ! -x "$SCRIPT_DIR/build/opi_ai" ]; then
    echo "[build] Compiling opi_ai from source (Release)..."
    cmake -S "$SCRIPT_DIR" -B "$SCRIPT_DIR/build" -DCMAKE_BUILD_TYPE=Release
    cmake --build "$SCRIPT_DIR/build" -j4
fi

exec "$SCRIPT_DIR/build/opi_ai" "${EXTRA_ARGS[@]}" "$@"
