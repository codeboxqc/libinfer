cmake_minimum_required(VERSION 3.22)
project(opi_ai VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Build libinfer + llama.cpp
set(INFER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE ON CACHE BOOL "" FORCE)
add_subdirectory(third_party/libinfer)

find_package(OpenSSL REQUIRED)
find_package(Threads REQUIRED)

# SQLite3 amalgamation with FTS5 enabled
add_library(sqlite3_static STATIC
    third_party/deps/sqlite3.c
)
target_include_directories(sqlite3_static PUBLIC third_party/deps)
target_compile_definitions(sqlite3_static PUBLIC
    SQLITE_ENABLE_FTS5
    SQLITE_THREADSAFE=1
)
if(UNIX)
    target_link_libraries(sqlite3_static PUBLIC dl Threads::Threads)
endif()

# Embed web UI files into generated header
set(EMBEDDED_UI_HEADER "${CMAKE_CURRENT_BINARY_DIR}/generated/embedded_ui.hpp")
add_custom_command(
    OUTPUT "${EMBEDDED_UI_HEADER}"
    COMMAND ${CMAKE_COMMAND}
        -DSRC_DIR=${CMAKE_CURRENT_SOURCE_DIR}/web
        -DOUT_FILE=${EMBEDDED_UI_HEADER}
        -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_ui.cmake
    DEPENDS
        ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_ui.cmake
        ${CMAKE_CURRENT_SOURCE_DIR}/web/index.html
        ${CMAKE_CURRENT_SOURCE_DIR}/web/manifest.json
        ${CMAKE_CURRENT_SOURCE_DIR}/web/sw.js
    COMMENT "Embedding web UI assets into embedded_ui.hpp"
)

add_executable(opi_ai
    src/main.cpp
    src/inference_queue.cpp
    src/downloader.cpp
    src/workspace.cpp
    src/database.cpp
    src/network.cpp
    src/tts.cpp
    third_party/deps/qrcodegen.cpp
    "${EMBEDDED_UI_HEADER}"
)

target_include_directories(opi_ai PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/deps
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/libinfer/include
    ${CMAKE_CURRENT_BINARY_DIR}/generated
)

target_compile_definitions(opi_ai PRIVATE
    CPPHTTPLIB_OPENSSL_SUPPORT
)

target_link_libraries(opi_ai PRIVATE
    infer_core
    sqlite3_static
    OpenSSL::SSL
    OpenSSL::Crypto
    Threads::Threads
)

if(UNIX AND NOT APPLE)
    set_target_properties(opi_ai PROPERTIES
        BUILD_RPATH "$ORIGIN:$ORIGIN/bin:$ORIGIN/third_party/libinfer:$ORIGIN/third_party/libinfer/third_party/llama.cpp/bin"
        INSTALL_RPATH "$ORIGIN"
    )
    if(TARGET ggml-cpu)
        add_custom_command(TARGET opi_ai POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_FILE:ggml-cpu>
                $<TARGET_FILE_DIR:opi_ai>/
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_FILE:ggml-cpu>
                $<TARGET_FILE_DIR:infer_core>/
            COMMENT "Copying ggml-cpu backend next to opi_ai and libinfer"
        )
    endif()
endif()
